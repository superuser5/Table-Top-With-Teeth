1. Open Elevated Administrator Command Prompt
2. Execute Install.bat
3. Send Output of AtomicRedTeam_Install.log 

